package AccessSpecifier;

public class AccessSpecifier2 {

	protected void display3()
	 {
	 System.out.println("\nProtected");
	 } 
}
