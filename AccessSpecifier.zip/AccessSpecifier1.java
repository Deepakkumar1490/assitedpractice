package AccessSpecifier;

class privateacesspe
{
 private void display2()
 {
 System.out.println("Private");
 }
}
public class AccessSpecifier1 extends AccessSpecifier2 {

	public void display1()
	{
		System.out.println("Public");
	}
	public static void main(String[] args)
	{
		AccessSpecifier1 a=new AccessSpecifier1();
		a.display1();
		privateacesspe b=new privateacesspe();
		// cannot access private method of another class
		AccessSpecifier2 c=new AccessSpecifier2();
		c.display3();
	}
}
